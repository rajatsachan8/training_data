package com.mindtree.exceptions;

public class NotABatsmanException extends Exception{
			public NotABatsmanException(){
				
			}
			
}
