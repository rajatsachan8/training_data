package com.mindtree.exceptions;

public class NotABowlerException extends Exception {
	
      public NotABowlerException(){
    	  
      }
}
