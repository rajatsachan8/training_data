package com.mindtree.exceptions;

public class InvalidTeamNameException extends Exception {
        
	   public InvalidTeamNameException(){
		   
	
	   }
}
