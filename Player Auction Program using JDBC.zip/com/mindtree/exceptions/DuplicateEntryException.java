package com.mindtree.exceptions;

public class DuplicateEntryException extends Exception{
	
     public DuplicateEntryException(){
    	 
     }
}  
