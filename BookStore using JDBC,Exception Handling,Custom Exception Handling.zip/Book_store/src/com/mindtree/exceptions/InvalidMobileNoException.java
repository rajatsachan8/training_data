package com.mindtree.exceptions;

public class InvalidMobileNoException extends Exception {
     public InvalidMobileNoException(){
    	 
     }
}
