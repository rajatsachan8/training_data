package com.mindtree.exceptions;

public class InvalidBookIdException extends Exception {
      public InvalidBookIdException(){
    	  
      }
}
