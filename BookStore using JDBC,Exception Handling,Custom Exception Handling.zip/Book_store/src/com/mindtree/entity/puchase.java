package com.mindtree.entity;

import java.sql.Date;

public class puchase {
   private book book1;
   private String customerName;
   private String customerMobileNo;
   private Date purchaseDate;
   private int amount;
   private int purchaseId;
   
}
