package com.mindtree.entity;

public class book {
       private int bookId;
       private String bookName;
       private String authorName;
       private String publisherName;
       private String categoryName;
       private int price;
   
}
