﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `assignment1`.`sp_Get_Grade` $$
CREATE PROCEDURE `assignment1`.`sp_Get_Grade` (IN var1 INT,OUT gra varchar(5))
BEGIN

select grade into gra from employee where empId=var1 ;


if (gra is null)
then
update employee Set grade='X' where empId=var1;
end if;

END $$
DELIMITER ;