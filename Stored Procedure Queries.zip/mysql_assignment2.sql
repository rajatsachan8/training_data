﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `assignment1`.`sp_Check_Grade` $$
CREATE PROCEDURE `assignment1`.`sp_Check_Grade` (IN var2 INT)
BEGIN    
call sp_Get_Grade(var2,@gra);

if @gra="X"
then
 select "Grade not found";
else
select @gra;
end if;
END $$

DELIMITER ;