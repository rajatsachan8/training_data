﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `assignment1`.`emp` $$
CREATE PROCEDURE `assignment1`.`emp` (IN var1 INT)
BEGIN
select empName from employee where empId=var1;
END $$

DELIMITER ;
