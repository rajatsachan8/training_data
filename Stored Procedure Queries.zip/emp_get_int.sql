﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `assignment1`.`emp_get_int` $$
CREATE PROCEDURE `assignment1`.`emp_get_int` (IN id int)
BEGIN
declare gra varchar(5);
declare ret int;
select grade into gra from employee where empId=id;

if gra="M"
then
set ret=1;
select ret;

elseif gra="L"
then
set ret=2;
select ret;

elseif gra="T"
then
set ret=3;
select ret;

elseif gra="X"
then
set ret=4;
select ret;

else
  set ret=0;
  select ret;

end if;
END $$

DELIMITER ;