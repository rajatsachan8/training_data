﻿DELIMITER $$

DROP PROCEDURE IF EXISTS `assignment1`.`increment_salary` $$
CREATE PROCEDURE `assignment1`.`increment_salary` ()
BEGIN
update employee set empSalary=empSalary+(0.15*empSalary);
END $$

DELIMITER ;